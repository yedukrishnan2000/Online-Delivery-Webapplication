
<?php include 'public_header.php' ?>


 <!-- ***** Main Banner Area Start ***** -->
    <div class="main-banner header-text" id="top">
        <div class="Modern-Slider">
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img src="images/odtlemon.png" alt="" style="min-height: 800px;max-height: 800px;">
                <div class="text-content">


               
           <!--    <h1 style="color: white;font-size: 60px; text-align: right; font-family: 'Times New Roman', serif;">Online Diary</h1> -->
                 
                </div>
            </div>
          </div>
          <!-- // Item -->
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img src="images/odtskyblue.png" alt="" style="min-height: 500px;max-height: 800px;">
                <div class="text-content">
               
            <!--      <h1 style="color: black;font-size: 50px">Online Diary</h1> -->
                 
                </div>
            </div>
          </div>
          <!-- // Item -->
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img src="images/odtmaroon.png" alt="" style="min-height: 800px;max-height: 800px;">
                <div class="text-content">
                <!--    <h1 style="color: white;font-size: 60px; text-align: right; font-family: 'Times New Roman', serif;">Online Diary</h1>-->
                 
             <!--     <h1 style="color: black;font-size: 50px">Online Diary</h1> -->
               
                </div>
            </div>
          </div>
          <!-- // Item -->
        </div>
    </div>
	
    
<?php include 'footer.php' ?>
