<?php include 'distributor_header.php' ?>

<!-- ***** Main Banner Area Start ***** -->
    <div class="main-banner header-text" id="top">
        <div class="Modern-Slider">
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img style="width: 1685px; height:681px;" src="images/odt3.png" alt="">
                <div class="text-content">
               
              <!--    <h1 align="top" style="color: white;font-size: 50px">Online Delivery of Diary Products</h1> -->
                 
                </div>
            </div>
          </div>
          <!-- // Item -->
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img style="width: 1685px; height:681px;" src="images/odt1.png" alt="">
                <div class="text-content">
               
               <!--     <h1 style="color: white;font-size: 50px">Online Delivery of Diary Products</h1> -->
                 
                </div>
            </div>
          </div>
          <!-- // Item -->
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img style="width: 1685px; height:681px;" src="images/odt2.png" alt="">
                <div class="text-content">
                 
                <!--    <h1 style="color: white;font-size: 50px">Online Delivery of Diary Products</h1>-->
               
                </div>
            </div>
          </div>
          <!-- // Item -->
        </div>
    </div>
	

<?php include 'footer.php' ?>