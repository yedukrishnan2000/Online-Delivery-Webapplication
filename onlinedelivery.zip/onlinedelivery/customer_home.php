<?php include 'customer_header.php' ?>

<!-- ***** Main Banner Area Start ***** -->
    <div class="main-banner header-text" id="top">
        <div class="Modern-Slider">
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img src="images/odtlemon.png" alt="" style="min-height: 500px;max-height: 800px;">
                <div class="text-content">
               
            <!--      <h1 style="color: black;font-size: 50px">You Wish <br>   We Deliver :)</h1> -->
                 
                </div>
            </div>
          </div>
          <!-- // Item -->
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img src="images/odtmaroon.png" alt="" style="min-height: 500px;max-height: 800px;">
                <div class="text-content">
               
              <!--    <h1 style="color: black;font-size: 50px">Chelorde readyavum, chelorde readyavoola. Intedh ready ayilla. Nnalum njammakkoru koyappoolya...... -->

</h1>
                 
                </div>
            </div>
          </div>
          <!-- // Item -->
          <!-- Item -->
          <div class="item">
            <div class="img-fill">
                <img src="images/odtskyblue.png" alt="" style="min-height: 500px;max-height: 800px;">
                <div class="text-content">
                 
            <!--      <h1 style="color: red;font-size: 50px">കേരളം കണ്ടുണരുന്ന നന്മ😁 </h1> -->
               
                </div>
            </div>
          </div>
          <!-- // Item -->
        </div>
    </div>
	

<?php include 'footer.php' ?>